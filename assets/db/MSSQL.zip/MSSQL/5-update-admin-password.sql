
-- Update IS admin user password on Production installations

UPDATE users SET password = '$1$ZF1U8.DQ$lfb.1mUr0AU2p3Xj.3PTR0' WHERE id = '0000000001';