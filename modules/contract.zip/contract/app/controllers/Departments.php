<?php

require COREPATH . "controllers/Departments.php";

?>