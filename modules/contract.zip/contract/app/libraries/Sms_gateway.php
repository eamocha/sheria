<?php

require COREPATH . "libraries/Sms_gateway.php";

?>