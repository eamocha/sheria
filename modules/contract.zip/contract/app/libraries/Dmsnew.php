<?php

require COREPATH . "libraries/Dmsnew.php";

?>