<?php

require COREPATH . 'language/french/is_auth_lang.php';
