<?php

require COREPATH . 'language/french/validation_message_lang.php';
