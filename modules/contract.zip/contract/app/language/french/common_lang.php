<?php

require COREPATH . 'language/french/common_lang.php';
