<?php

require COREPATH . 'language/spanish/validation_message_lang.php';
