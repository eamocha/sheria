<?php

require COREPATH . 'language/spanish/is_auth_lang.php';
