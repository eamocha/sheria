<?php

require COREPATH . 'language/spanish/common_lang.php';
