<?php

require COREPATH . 'language/english/common_lang.php';
