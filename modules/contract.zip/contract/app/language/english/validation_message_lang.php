<?php

require COREPATH . 'language/english/validation_message_lang.php';
