<?php

require COREPATH . 'language/english/is_auth_lang.php';
