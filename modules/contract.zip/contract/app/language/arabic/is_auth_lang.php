<?php

require COREPATH . 'language/arabic/is_auth_lang.php';
