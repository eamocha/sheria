<?php

require COREPATH . 'language/arabic/common_lang.php';
