<?php

require COREPATH . 'language/arabic/validation_message_lang.php';
