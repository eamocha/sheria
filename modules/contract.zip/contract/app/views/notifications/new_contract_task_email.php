<?php

require COREPATH . "views/notifications/new_contract_task_email.php";
