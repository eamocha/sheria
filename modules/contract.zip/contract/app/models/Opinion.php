<?php

require COREPATH . "models/Opinion.php";

?>