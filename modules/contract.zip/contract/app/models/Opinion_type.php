<?php

require COREPATH . "models/Opinion_type.php";

?>