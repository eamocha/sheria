<?php

require COREPATH . "models/Department.php";

?>